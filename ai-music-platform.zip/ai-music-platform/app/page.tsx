export default function Home() {
  return (
    <main style={{
      minHeight: '100vh',
      background: 'linear-gradient(to bottom right,#050816,#111827)',
      color: 'white',
      padding: '40px',
      fontFamily: 'sans-serif'
    }}>
      <h1 style={{fontSize:'48px',fontWeight:'bold'}}>
        AI Music Streaming Platform
      </h1>

      <p style={{marginTop:'20px',fontSize:'20px',maxWidth:'800px'}}>
        Premium cinematic streaming experience with AI recommendations,
        playlists, futuristic UI, and scalable architecture.
      </p>

      <div style={{
        marginTop:'40px',
        padding:'20px',
        border:'1px solid #333',
        borderRadius:'16px',
        background:'#111827'
      }}>
        <h2>Core Features</h2>
        <ul>
          <li>AI Playlist Generation</li>
          <li>Streaming Ready Architecture</li>
          <li>Background Playback</li>
          <li>Responsive Mobile UI</li>
          <li>CarPlay / Android Auto Ready</li>
        </ul>
      </div>
    </main>
  )
}