export const metadata = {
  title: 'AI Music Platform',
  description: 'Premium AI Music Streaming Platform'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}